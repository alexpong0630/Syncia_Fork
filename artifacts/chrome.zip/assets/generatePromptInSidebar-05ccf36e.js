import{_ as s}from"./default-33fb9962.js";const a=(t,e)=>s`
    #### Instructions:
    ${t}
    #### Original Text:
    ${e}
  `,d=(t,e)=>{var r;const o=a(t,e),n=document.getElementById("syncia_sidebar");n.style.width==="0px"&&(n.style.width="400px"),(r=n.contentWindow)==null||r.postMessage({action:"generate",prompt:o},"*")};export{d as g};
